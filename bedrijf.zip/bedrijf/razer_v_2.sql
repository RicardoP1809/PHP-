-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 17 apr 2019 om 11:06
-- Serverversie: 10.1.37-MariaDB
-- PHP-versie: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `razer v.2`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `besteldetail`
--

CREATE TABLE `besteldetail` (
  `IDbesteldetail` int(11) NOT NULL,
  `IDproduct` int(11) NOT NULL,
  `IDbestelling` int(11) NOT NULL,
  `aantal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `besteldetail`
--

INSERT INTO `besteldetail` (`IDbesteldetail`, `IDproduct`, `IDbestelling`, `aantal`) VALUES
(42, 1, 42, 2),
(43, 2, 43, 1),
(44, 1, 44, 2),
(45, 4, 45, 3),
(46, 1, 46, 2),
(47, 1, 47, 14),
(48, 1, 48, 6),
(49, 15, 49, 2),
(50, 10, 50, 3);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bestelling`
--

CREATE TABLE `bestelling` (
  `IDbestelling` int(11) NOT NULL,
  `IDklant` int(11) NOT NULL,
  `datum` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `bestelling`
--

INSERT INTO `bestelling` (`IDbestelling`, `IDklant`, `datum`) VALUES
(42, 8, '2019-04-02'),
(43, 8, '2019-04-02'),
(44, 9, '2019-04-05'),
(45, 9, '2019-04-05'),
(46, 7, '2019-04-05'),
(47, 9, '2019-04-15'),
(48, 9, '2019-04-15'),
(49, 9, '2019-04-15'),
(50, 9, '2019-04-16');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `klant`
--

CREATE TABLE `klant` (
  `IDklant` int(11) NOT NULL,
  `IDmedewerker` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `voornaam` varchar(100) NOT NULL,
  `achternaam` varchar(100) NOT NULL,
  `SaveCodeUser` varchar(100) NOT NULL,
  `telefoonnummer` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `straat` varchar(100) NOT NULL,
  `postcode` varchar(6) NOT NULL,
  `huisnummer` varchar(4) NOT NULL,
  `Stad` varchar(100) NOT NULL,
  `geboortedatum` date NOT NULL,
  `nieuwsbrief` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `klant`
--

INSERT INTO `klant` (`IDklant`, `IDmedewerker`, `username`, `voornaam`, `achternaam`, `SaveCodeUser`, `telefoonnummer`, `email`, `straat`, `postcode`, `huisnummer`, `Stad`, `geboortedatum`, `nieuwsbrief`) VALUES
(1, 0, 'JUSTricardo ', 'ricardo ', 'plompen', '$2y$10$nnf1Di00/Rro8nxOErpRHuYIXkt4vPFeEM/EvhIDSSvGMuBNp4pDe', '0645468521', 'ricardoplompen80@hotmail.com', 'slakkenveen', '3205GH', '432', 'Rotterdam', '2002-06-06', 'Nee'),
(2, 0, ' rick2', 'Rick', 'la rondelle ', '$2y$10$jBUgqdFnp7WTmc9Ve8Lf9OHxt1hOc19uDBIrCr1oaWk5DARbbI7sy', '0625252252', 'rickla@outlook.com', 'Coburn Hollow Road', '3625YH', '102', 'Poortugaal', '2001-06-06', 'Nee'),
(3, 0, 'remcoreus', 'Remco', 'Reus', '$2y$10$Uab2MKbIPTww.Zl.Kzcge.YZnUDjLjHmL0GbpCx1lDuMrTPl7Styy', '0625325494', 'Remcomeurs@hotmail.com', 'Sportweg', '3206FG', '102', 'Poortugaal', '2002-02-06', 'Ja'),
(4, 0, 'ryanm', 'Ryan ', 'meurs', '$2y$10$hijOvNxl.D/JK/.NDDXylO21hFsQJ/irDGFJCar212qvp6DpBKxzu', '0642590530', 'RyanLDennis@jourrapide.com', 'Coburn Hollow Road', '3625YH', '125', 'Eindhoven', '2006-11-30', 'Ja'),
(7, 1, 'rijs2001', 'Damian', 'rijsdijk', '$2y$10$yONMuyqg5rTjQC9jT8viK.Ylh4HJ9s2RPE9yPgvenUgHOOJcIv7NG', '0685452234', 'DamianRijsdijk2001@outlook.com', 'morsdoodsekade', '3262FD', '12', 'Amsterdam', '2001-05-08', 'Nee'),
(8, 0, 'JeffRick123', 'Rick', 'Jefferson', '$2y$10$K1o0S0CxYAxgpdkilLKk5OlY7yZ9sNmUuX42/NA6CND2W.lmots..', '0614542544', 'Jeffersonrick2002@hotmail.com', 'Coburn Hollow Road', '3252GF', '123', 'Rotterdam', '1997-05-31', 'Nee'),
(9, 1, 'keesjansen', 'Kees', 'Jansen', '$2y$10$we24VCVwcTxNKjr0kc5JMe3/MWxwuMRsgftu8i0G2cpoRmR37/PG6', '0685452234', 'k@j.nl', 'dorpshof', '3205GH', '33', 'Amsterdam', '1905-04-03', 'Nee');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `product`
--

CREATE TABLE `product` (
  `IDproduct` int(11) NOT NULL,
  `IDproductwaarde` int(11) NOT NULL,
  `productnaam` varchar(100) NOT NULL,
  `prijs` decimal(11,2) NOT NULL,
  `voorraad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `product`
--

INSERT INTO `product` (`IDproduct`, `IDproductwaarde`, `productnaam`, `prijs`, `voorraad`) VALUES
(1, 1, 'Razer Progen XDX', '80.00', 20),
(2, 2, 'Razer Red gaming head', '180.00', 80),
(3, 1, 'Razer Mouse pad', '45.00', 25),
(4, 1, 'Razer mouse Red', '50.00', 15),
(5, 3, 'Razer Red Keyboard', '190.00', 60),
(6, 1, 'Razer Progen Black', '120.00', 26),
(7, 1, 'Razer black green progen ', '120.00', 20),
(8, 3, 'Razer red progen keyboard', '25.00', 10),
(9, 3, 'Razer Keyboard Black', '126.00', 28),
(10, 3, 'RAZER chita wettworth keyboard', '35.00', 35),
(11, 1, 'RED PROGAN razer 2k', '84.00', 45),
(12, 2, 'RED BLACK snake Razer', '79.00', 21),
(13, 2, 'Razerbladedsnake Black', '199.00', 56),
(14, 3, 'Snake Keyboard Razer Mate Red', '89.99', 13),
(15, 1, '12 buttoned Mouse Razer', '119.00', 21),
(16, 2, 'Snake Razer head pink', '164.99', 0);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `besteldetail`
--
ALTER TABLE `besteldetail`
  ADD PRIMARY KEY (`IDbesteldetail`);

--
-- Indexen voor tabel `bestelling`
--
ALTER TABLE `bestelling`
  ADD PRIMARY KEY (`IDbestelling`);

--
-- Indexen voor tabel `klant`
--
ALTER TABLE `klant`
  ADD PRIMARY KEY (`IDklant`);

--
-- Indexen voor tabel `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`IDproduct`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `besteldetail`
--
ALTER TABLE `besteldetail`
  MODIFY `IDbesteldetail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT voor een tabel `bestelling`
--
ALTER TABLE `bestelling`
  MODIFY `IDbestelling` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT voor een tabel `klant`
--
ALTER TABLE `klant`
  MODIFY `IDklant` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT voor een tabel `product`
--
ALTER TABLE `product`
  MODIFY `IDproduct` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
