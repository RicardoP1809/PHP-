<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Razer || Profiel</title>
  </head>
  <body>
    <?php
    session_start();
      include 'navbar2.php';
      include 'DBconnect.php';

      //data ophalen
          try {
            $stmt = $db->prepare("SELECT * FROM klant WHERE IDklant = :IDklant");
            $stmt->bindValue(':IDklant', $_SESSION['IDklant']);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
          } catch (\Exception $e) {
            die("error!: " . $e->getMessage());
          }

          if(isset($_POST['wachtwoord'])) {
            header('Location: wachtwoord.php');
          }
    ?>
      <main class="container">
        <section class="head1">
        <h2>Profiel</h2>
      </section>
      <section class="article2">
        <form action="profiel.php" method="post">
          <input class="form-control" type="hidden" value="<?php echo $result['IDklant']; ?>" name="IDklant" readonly>
          <label>Voornaam</label>
          <input class="form-control" type="text" value="<?php echo $result['voornaam']; ?>" name="voornaam" readonly><br>
          <label>Achternaam</label>
          <input class="form-control" type="text" value="<?php echo $result['achternaam']; ?>" name="achternaam" readonly><br>
          <label>Telefoonnummer</label>
          <input class="form-control" type="text" value="<?php echo $result['telefoonnummer']; ?>" name="telefoonnummer" readonly><br>
          <label>E-mail</label>
          <input class="form-control" type="email" value="<?php echo $result['email']; ?>" name="email"  readonly><br>
          <label>straat</label>
          <input class="form-control mr-sm-6" type="text" value="<?php echo $result['straat']; ?>" name="straat" readonly><br>
          <label>Huisnummer</label>
          <input class="form-control mr-sm-6" type="text" value="<?php echo $result['huisnummer']; ?>" name="huisnummer" readonly><br>
          <label>Stad</label>
          <input class="form-control mr-sm-6" type="text" value="<?php echo $result['Stad']; ?>" name="stad" readonly><br>
          <label>Postcode</label>
          <input class="form-control mr-sm-6" type="text" value="<?php echo $result['postcode']; ?>" name="postcode" readonly><br><br>

          <button class="btn btn-block btn-primary" type="submit" name="submit">submit</button><br>
        </form>
      </section>
      </main>
    <?php
      include 'footer.html';
     ?>
  </body>
</html>
