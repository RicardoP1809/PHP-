<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta http-equiv="Refresh" content="3600" >
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  <title>Razer || Home</title>
</head>
  <body>

      <?php
      session_start();
        include ('DBconnect.php');
        include 'navbar2.php';
      ?>

      <div class="height">
          <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">

            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
            </ol>

          <div class="carousel-inner">

          <div class="carousel-item active">
            <img class="d-block w-100" src="../IMG/logo.jpg" alt="First slide">
          </div>

          <div class="carousel-item">
            <img class="d-block w-100" src="../IMG/razer1.jpg" alt="Second slide">
          </div>

          <div class="carousel-item">
            <img class="d-block w-100" src="../IMG/razer2.jpg" alt="Third slide">
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="../IMG/razer3.jpg" alt="Third slide">
          </div>

        </div>

        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>

      </div>
    </div>

      <div class="container">
        <div class="row">
          <div class="col-sm-4">
            <section class="head1">
              <h4>Mice</h4>
            </section>
            <article class="article1">
              Wij maken muizen van top kwaliteit speciaal voor jou! Onze muizen zijn voor de gamer als je een muis zuikt voor mmo wij hebben het zoek je er een voor rpg wij hebben het <br>
              je kan bij ons terecht voor alle muizen die jij zoekt probeer ze eens uit in een van de winkels.

            </article>
          </div>
          <div class="col-sm-4">
            <section class="head1">
              <h4>Headphones</h4>
            </section>
            <article class="article1">
              Wij maken headsets al een hele lange tijd met passie, we maken ze daarom ook van top kwaliteit ze zijn surroundsound 7.1 headsets. het maakt niet
              uit wat je zoekt bedraad of niet bedraad wij hebben het special voor jou. Kijk maar rond en misschien vind jij je droom headset.
            </article>
          </div>
          <div class="col-sm-4">
            <section class="head1">
              <h4>Keyboards</h4>
            </section>
            <article class="article1">
              Wij hebben verschillende toetsenboorden mechanical toetsenboorden en non mechanical toetsenboorden maar we maken ze allebij met pure passie ze zijn echt fantasties
              ze zijn in verschillende kleuren en maten, ze zijn van top kwaliteit en ze zijn voor de kamer heb jij er nog een nodig kijk rond op onze website.
            </article>
          </div>
        </div>
  </div>

    <?php
      include 'footer.html';
     ?>

  </body>
</html>
