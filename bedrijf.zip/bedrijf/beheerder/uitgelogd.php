<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      if(isset($_POST['loguit'])) {
        session_start();
        header('Refresh: 3; ../gast/index.php');
        echo 'u bent met success uitgelogd!';
        session_destroy();
        exit;
      }
     ?>
  </body>
</html>
