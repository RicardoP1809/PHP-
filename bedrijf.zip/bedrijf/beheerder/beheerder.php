<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="style.css">
    <title>Razer || keyboards assortiment</title>
  </head>
  <body>
    <?php
    $Msg = "";
    session_start();
        include ('DBconnect.php');
      include 'navbar3.php';


      if(isset($_POST['wijzig'])) {
        $idklant= $_POST['idklant'];
        $idmedewerker = $_POST['IDmedewerker'];

        $query = "UPDATE klant SET IDmedewerker = :IDmedewerker WHERE IDklant = :idklant";
        $stmt = $db->prepare($query);
        $stmt->bindValue(':IDmedewerker', $idmedewerker);
        $stmt->bindValue(':idklant', $idklant);
        $stmt->execute();
        $Msg = "klant is geupdate";
      }
      if(isset($_POST['wis'])) {
        $idklant= $_POST['idklant'];
        $idmedewerker = $_POST['IDmedewerker'];

        $query = "DELETE FROM klant WHERE IDklant = :idklant";
        $stmt = $db->prepare($query);
        $stmt->bindValue(':idklant', $idklant);
        $stmt->execute();
        $Msg = "klant is met success verwijderd";
      }


      if ($Msg != "") {
        echo '<div class="bg-dark text-danger container" id="errormes">';
        echo $Msg . "<br><br>";
        echo '</div>';
      }
    ?>

<main class="container">
  <section class="head1">
    <h2>promoten</h2>
  </section>
    <section class="article2">
    <?php
      try {
        $query = "SELECT * FROM klant";
        $stmt = $db->prepare($query);
        $stmt->execute();

        echo "<table border='1'>";
        echo '<thead>
                <td>IDklant</td>
                <td>Voornaam</td>
                <td>Achternaam</td>
                <td>klant</td>
                <td>Beheerder</td>
              </thead>';
        while($rij = $stmt->fetch(PDO::FETCH_ASSOC)) {
          if($_SESSION['IDklant'] == $rij['IDklant']) {
                      ?>
            <form action="beheerder.php" method="post">
              <tr>
                <td><input type="hidden" name="idklant" value="<?php echo($rij['IDklant'])?>"></td>
                <td><input type="text" name="voornaam" value="<?php echo($rij['voornaam'])?>" readonly></td>
                <td><input type="text" name="achternaam" value="<?php echo($rij['achternaam'])?>" readonly></td>
                <td><input type="text" name="IDmedewerker" value="<?php echo($rij['IDmedewerker'])?>"readonly></td>
                <td></td>
              </tr>
            </form>
          <?php
        } else {
          ?>
            <form action="beheerder.php" method="post">
              <tr>
                <td><input type="hidden" name="idklant" value="<?php echo($rij['IDklant'])?>"></td>
                <td><input type="text" name="voornaam" value="<?php echo($rij['voornaam'])?>" readonly></td>
                <td><input type="text" name="achternaam" value="<?php echo($rij['achternaam'])?>" readonly></td>
                <td><input type="text" name="IDmedewerker" value="<?php echo($rij['IDmedewerker'])?>"></td>
                <td><button class="btn btn-outline-success mr-sm-2" type="submit" name="wijzig">wijzig</button></td>
                <td><button class="btn btn-outline-success mr-sm-2" type="submit" name="wis">wis</button></td>
              </tr>
            </form>
          <?php
          }
        }
      } catch (\Exception $e) {

      }

     ?>
      </section>
   </main>

  </body>
</html>
