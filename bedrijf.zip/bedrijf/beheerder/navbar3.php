<?php

  if($_SESSION['blogin'] == false) {
    header("Location: ../gast/index.php");
    exit();
  }

include 'uitgelogd.php';
 ?>

<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="style.css">
  <title></title>
</head>


<nav class="navbar navbar-expand-lg navbar-light bg-dark text-light">

   <a class="navbar-brand" href="beheerderindex.php">
    <img src="../img/logo.jpg" alt="Logo" style="width:60px;">
  </a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="informatie.php">Informatie</a>
      </li>
      <li class="nav-item"><a class="nav-link"> | </a></li>
      <li class="nav-item">
        <a class="nav-link" href="woonplaats.php">Woonplaats</a>
      </li>
      <li class="nav-item"><a class="nav-link"> | </a></li>
      <li class="nav-item">
        <a class="nav-link" href="beheerder.php">Promoten</a>
      </li>
      <li class="nav-item"><a class="nav-link"> | </a></li>
      <li class="nav-item">
        <a class="nav-link" href="headsets.php">Headsets</a>
      </li>
      <li class="nav-item"><a class="nav-link"> | </a></li>
      <li class="nav-item">
        <a class="nav-link" href="keyboards.php">Keyboards</a>
      </li>
      <li class="nav-item"><a class="nav-link"> | </a></li>
      <li class="nav-item">
        <a class="nav-link" href="muizen.php">Muizen</a>
      </li>
    </li>
    <li class="nav-item"><a class="nav-link"> | </a></li>
    <li class="nav-item">
      <a class="nav-link" href="profielen.php">profielen</a>
    </li>
    </ul>

    <form class="form-inline my-2 my-lg-0" action="search.php" method="post">
      <input class="form-control mr-sm-2" type="text" placeholder="Zoek.." aria-label="Search" name="search">
      <button class="btn btn-outline-success mr-sm-2" type="submit" name="submit">  Zoek  </button>
    </form>
    <form class="form-inline my-2 my-lg-0" action="wachtwoord.php" method="post">
      <button class="btn btn-outline-success mr-sm-2" type="submit" href="wachtwoord.php"><?php echo '<i class="fas fa-user">  '. $_SESSION['username'] . '</i>'; ?></button>
    </form>
    <form class="" action="uitgelogd.php" method="post">
      <button class="btn btn-outline-success mr-sm-2" type="submit" name="loguit">  Log uit  </button>
    </form>
  </div>

</nav>
