<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="style.css">
    <title>Razer || keyboards assortiment</title>
  </head>
  <body>
    <?php
    $Msg = "";
    session_start();
        include ('DBconnect.php');
      include 'navbar3.php';


      if(isset($_POST['wijzig'])) {
        $telefoon = $_POST['Telnum'];
        $achternaam = $_POST['achternaam'];
        $email = $_POST['email'];
        $straat = $_POST['straat'];
        $huisnummer = $_POST['huisnummer'];
        $Stad = $_POST['Stad'];
        $postcode = $_POST['postcode'];
        $IDklant = $_POST['IDklant'];



        $query = "UPDATE klant SET achternaam = :achternaam, telefoonnummer = :telefoon, email = :email, straat = :straat, postcode = :postcode, huisnummer = :huisnummer, Stad = :stad WHERE IDklant = :IDklant";
        $stmt = $db->prepare($query);
        $stmt->bindValue(':achternaam', $achternaam);
        $stmt->bindValue(':telefoon', $telefoon);
        $stmt->bindValue(':email', $email);
        $stmt->bindValue(':straat', $straat);
        $stmt->bindValue(':huisnummer', $huisnummer);
        $stmt->bindValue(':stad', $Stad);
        $stmt->bindValue(':postcode', $postcode);
        $stmt->bindValue(':IDklant', $IDklant);
        if($stmt->execute()){
        $Msg = "klant is geupdate";
      }

      }
      if(isset($_POST['wis'])) {
        $idklant= $_POST['IDklant'];
        $idmedewerker = $_POST['IDmedewerker'];

        $query = "DELETE FROM klant WHERE IDklant = :idklant";
        $stmt = $db->prepare($query);
        $stmt->bindValue(':idklant', $idklant);
        $stmt->execute();
        $Msg = "klant is met success verwijderd";
      }


      if ($Msg != "") {
        echo '<div class="bg-dark text-danger container" id="errormes">';
        echo $Msg . "<br><br>";
        echo '</div>';
      }
    ?>

<main>
  <section class="head1">
    <h2>profielen</h2>
  </section>
    <section class="article2">
    <?php
      try {
        $query = "SELECT * FROM klant";
        $stmt = $db->prepare($query);
        $stmt->execute();

        echo "<table border='1'>";
        echo '<thead>
                <td>IDklant</td>
                <td>Achternaam</td>
                <td>email</td>
                <td>huisnummer</td>
                <td>straat</td>
                <td>postcode</td>
                <td>Stad</td>
                <td>Telefoonnummer</td>
              </thead>';
        while($rij = $stmt->fetch(PDO::FETCH_ASSOC)) {
          ?>
            <form action="profielen.php" method="post">
              <tr>
                <td><input type="hidden" name="IDklant" value="<?php echo($rij['IDklant'])?>"></td>
                <td><input type="text" name="achternaam" value="<?php echo($rij['achternaam'])?>" readonly></td>
                <td><input type="text" name="email" value="<?php echo($rij['email'])?>"></td>
                <td><input type="text" name="huisnummer" value="<?php echo($rij['huisnummer'])?>" ></td>
                <td><input type="text" name="straat" value="<?php echo($rij['straat'])?>" ></td>
                <td><input type="text" name="postcode" value="<?php echo($rij['postcode'])?>"></td>
                <td><input type="text" name="Stad" value="<?php echo($rij['Stad'])?>"></td>
                <td><input type="text" name="Telnum" value="<?php echo($rij['telefoonnummer'])?>" maxlength="10"></td>
                <td><button class="btn btn-outline-success mr-sm-2" type="submit" name="wijzig">wijzig</button></td>
                <td><button class="btn btn-outline-success mr-sm-2" type="submit" name="wis">wis</button></td>
              </tr>
            </form>
          <?php
        }
      } catch (\Exception $e) {

      }

     ?>
      </section>
   </main>

  </body>
</html>
