<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta http-equiv="Refresh" content="3600" >
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
  <title>Razer || Home</title>
</head>
  <body>

      <?php
      session_start(); 
        include ('DBconnect.php');
        include 'navbar3.php';
      ?>

      <div class="height">
          <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">

            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
            </ol>

          <div class="carousel-inner">

          <div class="carousel-item active">
            <img class="d-block w-100" src="../IMG/logo.jpg" alt="First slide">
          </div>

          <div class="carousel-item">
            <img class="d-block w-100" src="../IMG/razer1.jpg" alt="Second slide">
          </div>

          <div class="carousel-item">
            <img class="d-block w-100" src="../IMG/razer2.jpg" alt="Third slide">
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="../IMG/razer3.jpg" alt="Third slide">
          </div>

        </div>

        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>

      </div>
    </div>

      <div class="container">
        <div class="row">
          <div class="col-sm-4">
            <section class="head1">
              <h4>klanten in Rotterdam</h4>
            </section>
            <article class="article1">
              <?php

                  try {
                    include ('DBconnect.php');

                      $query = $db->prepare("SELECT voornaam, achternaam, Stad FROM klant WHERE Stad LIKE '%otterdam'" );
                      $query->execute();
                      $result = $query->fetchALL(PDO::FETCH_ASSOC);
                      echo "<table>";
                      echo "<thead>";
                      echo "<tr>";
                      echo "<th>Voornaam:</th>";
                      echo "<th>Achternaam:</th>";
                      echo "<th>Stad:</th>";
                      echo "</tr>";
                      echo "</thead>";
                      echo "<tbody>";
                      foreach ($result as &$data) {
                        echo "<tr>";
                        echo "<td>" . $data["voornaam"] . "</td>";
                        echo "<td>" . $data["achternaam"] . "</td>";
                        echo "<td>" . $data["Stad"] . "</td>";
                        echo "</tr>";

                      }

                      echo "</tbody>";
                      echo "</table>";
                  }
                  catch(PDOExeption $e) {
                    die("Error!: " . $e->getMessage());
                  }
                   ?>
            </article>
          </div>
          <div class="col-sm-4">
            <section class="head1">
              <h4>Klanten in Amsterdam</h4>
            </section>
            <article class="article1">
              <?php

                  try {
                    include ('DBconnect.php');

                      $query = $db->prepare("SELECT voornaam, achternaam, Stad FROM klant WHERE Stad LIKE '%msterdam'" );
                      $query->execute();
                      $result = $query->fetchALL(PDO::FETCH_ASSOC);
                      echo "<table>";
                      echo "<thead>";
                      echo "<tr>";
                      echo "<th>Voornaam:</th>";
                      echo "<th>Achternaam:</th>";
                      echo "<th>Stad:</th>";
                      echo "</tr>";
                      echo "</thead>";
                      echo "<tbody>";
                      foreach ($result as &$data) {
                        echo "<tr>";
                        echo "<td>" . $data["voornaam"] . "</td>";
                        echo "<td>" . $data["achternaam"] . "</td>";
                        echo "<td>" . $data["Stad"] . "</td>";
                        echo "</tr>";

                      }

                      echo "</tbody>";
                      echo "</table>";
                  }
                  catch(PDOExeption $e) {
                    die("Error!: " . $e->getMessage());
                  }
                   ?>
            </article>
          </div>
          <div class="col-sm-4">
            <section class="head1">
              <h4>Klanten in Eindhoven</h4>
            </section>
            <article class="article1">
              <?php

                  try {
                    include ('DBconnect.php');

                      $query = $db->prepare("SELECT voornaam, achternaam, Stad FROM klant WHERE Stad LIKE '%indhoven'" );
                      $query->execute();
                      $result = $query->fetchALL(PDO::FETCH_ASSOC);
                      echo "<table>";
                      echo "<thead>";
                      echo "<tr>";
                      echo "<th>Voornaam:</th>";
                      echo "<th>Achternaam:</th>";
                      echo "<th>Stad:</th>";
                      echo "</tr>";
                      echo "</thead>";
                      echo "<tbody>";
                      foreach ($result as &$data) {
                        echo "<tr>";
                        echo "<td>" . $data["voornaam"] . "</td>";
                        echo "<td>" . $data["achternaam"] . "</td>";
                        echo "<td>" . $data["Stad"] . "</td>";
                        echo "</tr>";

                      }

                      echo "</tbody>";
                      echo "</table>";
                  }
                  catch(PDOExeption $e) {
                    die("Error!: " . $e->getMessage());
                  }
                   ?>
            </article>
          </div>
        </div>
  </div>

    <?php
      include 'footer.html';
     ?>

  </body>
</html>
