<?php
  $db = new PDO("mysql:hostname=localhost;dbname=razer v.2","root","");
 ?>
