<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Razer || keyboards assortiment</title>
  </head>
  <body>
    <?php
    $Msg = "";
    session_start(); 
        include ('DBconnect.php');
      include 'navbar3.php';


      if(isset($_POST['wijzig'])) {
        $idproduct = $_POST['idproduct'];
        $product = $_POST['naam'];
        $prijs = $_POST['prijs'];
        $voorraad = $_POST['voorraad'];

        $query = "UPDATE product SET productnaam = :product, prijs = :prijs, voorraad = :voorraad WHERE IDproduct = :idproduct";
        $stmt = $db->prepare($query);
        $stmt->bindValue(':idproduct', $idproduct);
        $stmt->bindValue(':product', $product);
        $stmt->bindValue(':prijs', $prijs);
        $stmt->bindValue(':voorraad', $voorraad);
        $stmt->execute();
        $Msg = "product is geupdate";
      }
      if(isset($_POST['wis'])) {
        $idproduct = $_POST['idproduct'];
        $product = $_POST['naam'];
        $prijs = $_POST['prijs'];
        $voorraad = $_POST['voorraad'];

        $query = "DELETE FROM product WHERE IDproduct = :idproduct";
        $stmt = $db->prepare($query);
        $stmt->bindValue(':idproduct', $idproduct);
        $stmt->execute();
        $Msg = "product is met success verwijderd";
      }

      if(isset($_POST['nieuw'])) {
        $product = $_POST['naam'];
        $prijs = $_POST['prijs'];
        $voorraad = $_POST['voorraad'];
        if(empty($product) || empty($prijs) || empty($voorraad)) {
          $Msg = "alle velden moeten ingevuld worden";
        } else {
        $query = "INSERT INTO product(IDproductwaarde, productnaam, prijs, voorraad) VALUES (2, :product, :prijs, :voorraad)";
        $stmt = $db->prepare($query);
        $stmt->bindValue(':product', $product);
        $stmt->bindValue(':prijs', $prijs);
        $stmt->bindValue(':voorraad', $voorraad);
        $stmt->execute();
        $Msg = "product is met success toegevoegd";
      }
      }

      if ($Msg != "") {
        echo '<div class="bg-dark text-danger container" id="errormes">';
        echo $Msg . "<br><br>";
        echo '</div>';
      }
    ?>

 <main class="container">
  <section class="head1">
    <h2>headsets assortiment</h2>
  </section>
    <section class="article2">
    <?php
      try {
        $query = "SELECT * FROM product WHERE IDproductwaarde = 2";
        $stmt = $db->prepare($query);
        $stmt->execute();

        echo "<table border='1'>";
        echo '<thead>
                <td>IDproduct</td>
                <td>Product naam</td>
                <td>Product prijs</td>
                <td>Product voorraad</td>
              </thead>';
        while($rij = $stmt->fetch(PDO::FETCH_ASSOC)) {
          ?>
            <form action="headsets.php" method="post">
              <tr>
                <td><input type="hidden" name="idproduct" value="<?php echo($rij['IDproduct'])?>"></td>
                <td><input type="text" name="naam" value="<?php echo($rij['productnaam'])?>"></td>
                <td><input type="text" name="prijs" value="<?php echo($rij['prijs'])?>"></td>
                <td><input type="text" name="voorraad" value="<?php echo($rij['voorraad'])?>"></td>
                <td><button class="btn btn-outline-success mr-sm-2" type="submit" name="wijzig">wijzig</button></td>
                <td><button class="btn btn-outline-success mr-sm-2" type="submit" name="wis">wis</button></td>
              </tr>
            </form>
          <?php
        }
        ?>
        <form class="" action="headsets.php" method="post">
            <tr>
              <td><input type="hidden" name="idproduct" value="<?php echo($rij['IDproduct'])?>"></td>
              <td><input type="text" name="naam" value="<?php echo($rij['productnaam'])?>"></td>
              <td><input type="text" name="prijs" value="<?php echo($rij['prijs'])?>"></td>
              <td><input type="text" name="voorraad" value="<?php echo($rij['voorraad'])?>"></td>
              <td><button class="btn btn-outline-success mr-sm-2" type="submit" name="nieuw">nieuwe</button></td>
            </tr>
        </form>
      <?php
      } catch (\Exception $e) {

      }

     ?>
      </section>
   </main>

  </body>
</html>
