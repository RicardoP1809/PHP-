<?php
$reg_hash = $hashedpwd;
 ?>
