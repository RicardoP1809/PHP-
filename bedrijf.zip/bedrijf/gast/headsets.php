<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
      <link rel="stylesheet" type="text/css" href="style.css">
    <title>Razer || Headset assortiment</title>
  </head>

  <body>
    <?php
      include 'navbar1.php';
    ?>

<main class="container">
  <section class="head1">
  <h2>Headset assortiment</h2>
</section>
<section class="article2">
<?php

    try {
      include ('DBconnect.php');

        $query = $db->prepare("SELECT IDproduct, productnaam FROM product WHERE IDproductwaarde LIKE '2'");
        $query->execute();
        $result = $query->fetchALL(PDO::FETCH_ASSOC);
        echo "<table>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>IDproduct:</th>";
        echo "<th>Productnaam:</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        foreach ($result as &$data) {
          echo "<tr>";
          echo "<td>" . $data["IDproduct"] . "</td>";
          echo "<td>" . $data["productnaam"] . "</td>";
          echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
    }
    catch(PDOExeption $e) {
      die("Error!: " . $e->getMessage());
    }
     ?>
   </main>
 </section>

 <div id="global">

 </div>
     <?php
        include ('footer.html');
      ?>
  </body>
</html>
