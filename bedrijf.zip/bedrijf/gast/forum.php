 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>Razer || Forum</title>
   </head>
   <body>


      <?php
        include 'mainbar.php';
        include 'DBconnect.php';
       ?>

       <?php

        


        ?>

      <main class="container">
        <section class="article1">
         <form class="" action="forum.php" method="post">
          <textarea name="forum" rows="8" cols="80" class="form-control" placeholder="type hier wat intresants..."></textarea>
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="submit">  submit  </button>
         </form>
       </section>
      </main>

       <?php
          include 'footer.html';
        ?>
   </body>
 </html>
