<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>reken 2</title>
  </head>
  <body>

    <?php
      include 'nav.html';
     ?>

     <br>

    <?php

      if(isset($_POST['submit'])) {

        $type = $_POST['tselect'];
        $kilo = $_POST['aantalkm'];

        if(is_numeric($_POST['aantalkm'])) {

          if($type == 1) {
            $prijs = 25.00 + (0.75 * $kilo);
            echo '         Type Auto: Standaard.';
            echo '         <br>';
            echo '         Aantal Gereden Kilometers: ' . $kilo;
            echo '         <br>';
            echo '         Prijs: ' . $prijs;
          }
          else if ($type == 2 ) {
             $prijs = 35.00 + (1.25 * $kilo);
            echo '         Type Auto: Luxe.';
            echo '         <br>';
            echo '         Aantal Gereden Kilometers: ' . $kilo;
            echo '         <br>';
            echo '         Prijs: ' . $prijs;
          }

        }

      }


     ?>

     <br>



     <section class="container bg-danger">

       <form action="reken2.php" method="POST">

         <h2>type auto:</h2>
         <select name="tselect"  class="form-control"  required>
           <option>1</option>
           <option>2</option>
         </select>
         <br>
         <br>
         <input type="number" class="form-control" name="aantalkm" value="" required>
         <br>
         <br>
         <button type="submit" class="btn btn-primary" name="submit">submit</button>
       </form>

   </section>

  </body>
</html>
