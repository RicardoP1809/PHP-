<!DOCTYPE html>
<html>
    <head>
        <title>Reken 8</title>
        <meta charset='utf-8'>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>

          <?php
            include 'nav.html';
           ?>

      <?php
                 if(isset($_POST['submit'])) {
                     $max = $_POST['FIB'];
                     $num1 = 0;
                     $num2 = 1;

                      echo "Fibonaccireeks:";
                      for ($i = 0; $i <= $max; $i++) {
                         echo " - " . $num1 . " <br> ";
                          $num3 = $num2 + $num1;
                          $num1 = $num2;
                          $num2 = $num3;
                      }
                  }
                  ?>
                  <section class="container bg-danger">
                  <form action='reken8.php' method='POST'>
                      <div class="form-group">
                          <h2>Fibonaccireeks</h2>
                          <input name="FIB" type="number" min="1" placeholder="Max Nummer" class="form-control" placeholder='0' required>
                      </div>
                      <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
        </section>
    </body>
</html>
