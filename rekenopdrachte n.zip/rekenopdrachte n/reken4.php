<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>reken 4</title>
  </head>
  <body>

    <?php
      include 'nav.html';
     ?>

     <br>

    <?php


      if(isset($_POST['submit'])) {

        if(is_numeric($_POST['basis']) && is_numeric($_POST['rente']) && is_numeric($_POST['jaar'])) {

          $basis = $_POST['basis'];
          $rente = $_POST['rente'];
          $jaar = $_POST['jaar'];

          date_default_timezone_set("Europe/Amsterdam");
          $startjaar = date("Y");

          echo '         Rente: ' . $rente;
          for($i = $startjaar ; $i <= $jaar ; $i++) {
              if($i == $startjaar) {
                  echo '         Jaar: ' . $i;
                  echo '         Basis: ' . round($basis, 2)."<br>";
              } else {
                  $basis = $basis * ($rente / 100 + 1);
                  echo '         Jaar: ' . $i;
                  echo '         Basis: ' . round($basis, 2)."<br>";
              }
          }



        }




      }


     ?>

     <br>



     <section class="container bg-danger">

       <form action="reken4.php" method="POST">
         <h2>rente berekenen:</h2>
         <input type="number" name="basis" class="form-control" placeholder="basis bedrag..." required>
         <br>
         <input type="number" name="rente" class="form-control" placeholder="rente percentage..." required >
         <br>
         <input type="number" name="jaar" class="form-control" placeholder="aantal jaar..." required>
         <br>
         <button type="submit" class="btn btn-primary" name="submit">submit</button>
       </form>

   </section>

  </body>
</html>
