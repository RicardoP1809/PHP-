<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>reken 1</title>
  </head>
  <body>
    <?php
      include 'nav.html';

      ?>

        <br>

      <?php

        if(isset($_POST['submit'])) {

          if(is_numeric($_POST['straal'])){

            $r = $_POST['straal'];

            $ant = (4/3) * pow($r, 3) * pi();

            echo 'het de straal is: ' . $r;
            echo '<br>';
            echo 'de inhoud van de bol is: ' . $ant;
          }


        }


      ?>

      <br>

      <section class="container bg-danger">

        <form action="reken1.php" method="POST">
          <h2>straal</h2>
          <input name="straal" type="number" class="form-control" placeholder="Straal..." required>
          <br>
          <br>
          <button type="submit" class="btn btn-primary" name="submit">submit</button>
        </form>

    </section>
  </body>
</html>
