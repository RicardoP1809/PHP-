<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
      <link rel="stylesheet" href="style.css" type="text/css">
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <?php

    $x = $_POST['x'];
    $y = $_POST['y'];

      if (isset($_POST['plus']) || isset($_POST['min']) || isset($_POST['delen']) || isset($_POST['keer'])) {
        if (is_numeric($_POST['y']) && is_numeric ($_POST['x'])){
          if (isset($_POST['min'])) {
            $ant = $x - $y;
            echo "<section>";
            echo $ant;
            echo "</section>";
          }
          if (isset($_POST['plus'])) {
            $ant = $x + $y;
            echo "<section>";
            echo $ant;
            echo "</section>";
          }
          if (isset($_POST['keer'])) {
            $ant = $x * $y;
            echo "<section>";
            echo $ant;
            echo "</section>";
          }
          if (isset($_POST['delen'])) {
            if ($y == 0){
              echo "<section>";
              echo "INF";
              echo "</section>";
            }
              else {
              $ant = $x / $y;
              echo "<section>";
              echo $ant;
              echo "</section>";
          }
          }

        }
        else {
          echo "<section>";
          echo "vul beide dingen in!!";
          echo "</section>";
        }
      }

      if (isset($_POST['kwadr']) || isset($_POST['wortel']) || isset($_POST['tafel'])) {
        if (empty($_POST['y']) && is_numeric($_POST['x'])) {
          if (isset($_POST['kwadr'])) {
            $ant = pow($x,2);
            echo "<section>";
            echo $ant;
            echo "</section>";
          }
          if (isset($_POST['wortel'])){
            $ant = pow($x, 1/2);
            echo "<section>";
            echo $ant;
            echo "</section>";
          }
          if (isset($_POST['tafel'])){
            $ant = "de tafel van" .$x. ":<br>";
            for($i = 1; $i <= 10; $i++) {
                $prod = $i * $x;
                $ant = $ant."$i x $x=$prod:<br>";
            }
            echo "<section>";
            echo $ant;
            echo "</section>";
          }
        }
        else {
          echo "<section>";
          echo "vul maar alleen maar x  in!!";
          echo "</section>";

        }
      }

      if (isset($_POST['tot'])){
        if (is_numeric($_POST['y']) && is_numeric($_POST['x'])){
            $ant = pow($x,$y);
            echo "<section>";
            echo $ant;
            echo "</section>";
        }
        else {
          echo "<section>";
            echo "vul maar alles in!";
            echo "</section>";
        }
      }

     ?>

    <form class="" action="rekenmachine.php" method="post">

      	<input type="number" name="x" placeholder="  Dit is: X" step="any">
        <br>
        <input type="number" name="y" placeholder="  Dit is: Y" step="any">
        <br>

      <button type="submit" name="plus">+</button>
      <button type="submit" name="min">-</button>
      <button type="submit" name="delen">/</button>
      <br>
      <button type="submit" name="keer">*</button>
      <button type="submit" name="kwadr">X²</button>
      <button type="submit" name="wortel">√X</button>
      <br>
      <button type="submit" name="tot">X^y</button>
      <button type="submit" name="tafel">tafel</button>
      <button type="submit" name="clear" id="clear">C</button>

    </form>


  </body>
</html>
